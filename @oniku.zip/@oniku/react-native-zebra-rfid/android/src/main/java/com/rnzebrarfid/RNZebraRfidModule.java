package com.rnzebrarfid;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableNativeArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import android.os.AsyncTask;
import android.util.EventLog;
import android.util.Log;
import androidx.annotation.Nullable;

import com.zebra.rfid.api3.BATTERY_EVENT;
import com.zebra.rfid.api3.READER_TYPE;
import com.zebra.rfid.api3.RFID_EVENT_TYPE;
import com.zebra.rfid.api3.RfidEventsListener;
import com.zebra.rfid.api3.Antennas;
import com.zebra.rfid.api3.ReaderDevice;
import com.zebra.rfid.api3.RFIDReader;
import com.zebra.rfid.api3.Readers;
import com.zebra.rfid.api3.OperationFailureException;
import com.zebra.rfid.api3.InvalidUsageException;
import com.zebra.rfid.api3.TriggerInfo;
import com.zebra.rfid.api3.TagData;
import com.zebra.rfid.api3.RfidReadEvents;
import com.zebra.rfid.api3.RfidStatusEvents;
import com.zebra.rfid.api3.RfidEventsListener;
import com.zebra.rfid.api3.TagAccess;
import com.zebra.rfid.api3.Readers.RFIDReaderEventHandler;

import com.zebra.rfid.api3.BEEPER_VOLUME;
import com.zebra.rfid.api3.ACCESS_OPERATION_CODE;
import com.zebra.rfid.api3.ACCESS_OPERATION_STATUS;
import com.zebra.rfid.api3.HANDHELD_TRIGGER_EVENT_TYPE;
import com.zebra.rfid.api3.ENUM_TRANSPORT;
import com.zebra.rfid.api3.START_TRIGGER_TYPE;
import com.zebra.rfid.api3.STATUS_EVENT_TYPE;
import com.zebra.rfid.api3.STOP_TRIGGER_TYPE;
import com.zebra.rfid.api3.ENUM_TRIGGER_MODE;
import com.zebra.rfid.api3.WRITE_FIELD_CODE;
import com.zebra.rfid.api3.MEMORY_BANK;
import com.zebra.rfid.api3.SESSION;
import com.zebra.rfid.api3.INVENTORY_STATE;
import com.zebra.rfid.api3.SL_FLAG;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.HashMap;

import android.widget.Toast;



public class RNZebraRfidModule extends ReactContextBaseJavaModule implements RfidEventsListener {
  private final String TAG = "ReactNative";
  private final ReactApplicationContext reactContext;

  private Readers readers;
  private List<ReaderDevice> devices;
  private List<TagData> tags;
  private int MAX_POWER = 270;

  private int batteryLevel = 0;

  public RNZebraRfidModule(ReactApplicationContext reactContext) {
    super(reactContext);
    this.reactContext = reactContext;
    this.devices = new ArrayList<ReaderDevice>();
    this.tags = new ArrayList<TagData>();
    this.readers = new Readers(reactContext, ENUM_TRANSPORT.ALL);
  }

  @Override
  public String getName() {
    return "RNZebraRfid";
  }

  @ReactMethod
  public void getAvailableDevices(Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          devices = readers.GetAvailableRFIDReaderList();

          final WritableArray payloads = new WritableNativeArray();
          for (ReaderDevice device : devices) {
            payloads.pushMap(toDevicePayload(device));
          }
          promise.resolve(payloads);

        } catch (InvalidUsageException e) {
          promise.reject(e);
        }
      }
    }).start();
  }



  @ReactMethod
  public void connect(final String deviceName, Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        devices.stream()
                .filter(x -> x.getName().equals(deviceName))
                .findFirst()
                .map(x -> x.getRFIDReader())
                .ifPresent(x -> {
                  Log.d(TAG, "connect to " + deviceName);
                  try {
                    if(!x.isConnected()){
                      x.connect();
                    }
                    initRFIDReader(x);
                  } catch (InvalidUsageException | OperationFailureException e) {
                    promise.reject(e);
                    return;
                  }
                });
        promise.resolve(deviceName);
        return;
      }
    }).start();
  }

  @ReactMethod
  public void disconnect(final String deviceName, Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        devices.stream()
                .filter(x -> x.getName().equals(deviceName))
                .findFirst()
                .map(x -> x.getRFIDReader())
                .ifPresent(x -> {
                  try {
                    if(x.isConnected()){
                      x.disconnect();
                    }
                  } catch (InvalidUsageException | OperationFailureException e) {
                    promise.reject(e);
                    return;
                  }
                });
        promise.resolve(deviceName);
        return;
      }
    }).start();
  }
  @ReactMethod
  public void stopTagLocate(Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          getRFIDReader().ifPresent(x -> {
            try {
              x.Actions.Inventory.stop();
              promise.resolve(true);

            } catch (InvalidUsageException e) {
              e.printStackTrace();
              promise.reject(e);
            } catch (OperationFailureException e) {
              e.printStackTrace();
              promise.reject(e);
            }

          });
        } catch (Exception e) {
          e.printStackTrace();
          promise.reject(e);
        }
      }
    }).start();
  }
  @ReactMethod
  public void startTagLocate(String tag,String epm, Promise promise) {
    Log.i("Test Tag", "In start Tag Locate");
    try {
      new Thread(new Runnable() {
        @Override
        public void run() {
          getRFIDReader().ifPresent(x -> {
            try {
              x.Actions.TagLocationing.Perform(tag, null,null);
              Log.i("Test Tag", "Finish start Tag Locate");

              promise.resolve(true);
            } catch (InvalidUsageException e) {
              e.printStackTrace();
              promise.reject(e);
            } catch (OperationFailureException e) {
              e.printStackTrace();
              promise.reject(e);
            }
          });
        }
      }).start();
    } catch (Exception e) {
      e.printStackTrace();
      promise.reject(e);
    }
  }

  @ReactMethod
  public void setUniqueTag(Boolean tag, Promise promise) {

    new Thread(new Runnable() {
      @Override
      public void run() {
        try {

          getRFIDReader().ifPresent(x -> {
            try {
              x.Config.setUniqueTagReport(tag);
              promise.resolve(true);
              return;
            } catch (InvalidUsageException | OperationFailureException e) {
              e.printStackTrace();
              promise.reject(e);
              return;
            }
          });

        } catch (Exception e) {
          e.printStackTrace();
          promise.reject(e);
        }
      }
    }).start();
  }

  @ReactMethod
  public void setMode(final String mode, Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        getRFIDReader().ifPresent(x -> {
          try {
            if(mode.equals("RFID")){
              x.Config.setTriggerMode(ENUM_TRIGGER_MODE.RFID_MODE, true);
            }else if(mode.equals("BARCODE")){
              x.Config.setTriggerMode(ENUM_TRIGGER_MODE.BARCODE_MODE, true);
            }
            promise.resolve(mode);
            return;
          } catch (InvalidUsageException | OperationFailureException e) {
            e.printStackTrace();
            promise.reject(e);
            return;
          }
        });
      }
    }).start();
  }
  @ReactMethod
  public void setPower(final int power, Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        getRFIDReader().ifPresent(x -> {
          try {
            final Antennas.AntennaRfConfig  config = x.Config.Antennas.getAntennaRfConfig(1);
            config.setTransmitPowerIndex(power);
            x.Config.Antennas.setAntennaRfConfig(1, config);
            promise.resolve(power);
            return;
          } catch (InvalidUsageException | OperationFailureException e) {
            e.printStackTrace();
            promise.reject(e);
            return;
          }
        });
      }
    }).start();
  }

  @ReactMethod
  public void  getPower(Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        getRFIDReader().ifPresent(x -> {
          try {
            final Antennas.AntennaRfConfig  config = x.Config.Antennas.getAntennaRfConfig(1);
            int power = config.getTransmitPowerIndex();
            System.out.println(power);
            promise.resolve(power);
            return;
          } catch (InvalidUsageException | OperationFailureException e) {
            e.printStackTrace();
            promise.reject(e);
            return;
          }
        });
      }
    }).start();
  }

  @ReactMethod
  public  void  getBatteryLevel(Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        getRFIDReader().ifPresent(x -> {
          try {
            promise.resolve(batteryLevel);
            return;
          } catch (Exception e) {
            e.printStackTrace();
            promise.reject(e);
            return;
          }
        });
      }
    }).start();
  }
  @ReactMethod
  public  void isConnected(Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          Boolean isPresent = getRFIDReader().isPresent();
          if(isPresent) {
            getRFIDReader().ifPresent(x -> {
              Log.d("anjumReader", Boolean.toString(x.isConnected()));
              promise.resolve(x.isConnected());
            });

          } else {
            promise.resolve(false);
          }
        } catch (Exception e) {
          e.printStackTrace();
          promise.reject(e);
        }
      }}).start();
  }


  @ReactMethod
  public void getRSSI(String tagId, Promise promise) {
    new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          promise.resolve(tags.stream()
                  .filter(x -> x.getTagID().equals(tagId))
                  .findFirst().get().getPeakRSSI());
        } catch (Exception e) {
          e.printStackTrace();
          promise.reject(e);
          return;
        }

      }
    });
  }



  private void initRFIDReader(RFIDReader rfidReader) {
    try {
      rfidReader.Events.addEventsListener(this);
      rfidReader.Events.setHandheldEvent(true);
      rfidReader.Events.setTagReadEvent(true);
      rfidReader.Config.getDeviceStatus(true, false, false);
      rfidReader.Events.setBatteryEvent(true);
    } catch (InvalidUsageException | OperationFailureException e) {
      e.printStackTrace();
      Log.d(TAG,"ConfigureReader error");
    }
  }

  private WritableMap toDevicePayload(final ReaderDevice device) {
    final WritableMap payload = new WritableNativeMap();
    payload.putString("name", device.getName());
    payload.putString("address", device.getAddress());
    return payload;
  }

  public void eventStatusNotify(RfidStatusEvents event) {
    Log.d(TAG, "Status Notification: " + event.StatusEventData.getStatusEventType());
    if (event.StatusEventData.HandheldTriggerEventData.getHandheldEvent() == HANDHELD_TRIGGER_EVENT_TYPE.HANDHELD_TRIGGER_PRESSED) {
      this.performInventory();
    }

    if (event.StatusEventData.HandheldTriggerEventData.getHandheldEvent() == HANDHELD_TRIGGER_EVENT_TYPE.HANDHELD_TRIGGER_RELEASED) {
      this.stopInventory();
    }

    if (event.StatusEventData.getStatusEventType() == STATUS_EVENT_TYPE.BATTERY_EVENT) {
      batteryLevel = event.StatusEventData.BatteryData.getLevel();
    }
  }

  private void performInventory() {
    this.getRFIDReader().ifPresent(x -> {
      try {
        x.Actions.Inventory.perform();
      } catch (InvalidUsageException | OperationFailureException e) {
        e.printStackTrace();
      }
    });
  }

  public void eventReadNotify(RfidReadEvents event) {

    this.getRFIDReader().ifPresent(x -> {
      TagData[] myTags = x.Actions.getReadTags(100);
      final WritableArray payload = new WritableNativeArray();
      if (myTags != null) {
        for (int index = 0; index < myTags.length; index++) {
          int tag = index;
          if (myTags[index].isContainsLocationInfo()) {
            final WritableMap map1 = new WritableNativeMap();
            map1.putInt("rssi", myTags[tag].LocationInfo.getRelativeDistance());
            this.sendEvent("onProximityRead", map1);
          }
          else{
            final WritableMap map = new WritableNativeMap();
            map.putString("id", myTags[tag].getTagID());
            map.putInt("rssi", myTags[tag].getPeakRSSI());
            payload.pushMap(map);
            this.sendEvent("onRfidRead", payload);
          }
        }
      }


    });
  }



  private void stopInventory() {
    this.getRFIDReader().ifPresent(x -> {
      try {
        x.Actions.Inventory.stop();
      } catch (InvalidUsageException | OperationFailureException e) {
        e.printStackTrace();
      }
    });
  }

  private Optional<RFIDReader> getRFIDReader(){
    return this.devices.stream()
            .map(x -> x.getRFIDReader())
            .filter(x -> x.isConnected())
            .findFirst();
  }

  private void sendEvent(String eventName, @Nullable WritableMap params) {
    reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName, params);
  }


  private void sendEvent(String eventName, @Nullable WritableArray params) {
    reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName, params);
  }

  private void sendEvent(String eventName, @Nullable String params) {
    reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName, params);
  }
}

